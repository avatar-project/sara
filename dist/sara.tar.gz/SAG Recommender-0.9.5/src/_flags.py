# -*- coding: utf-8 -*-
__all__ = [
    "_show_bar",
    "_multiprocessing",
    "_jupiter_support",
    "_ignore_missing",
    "_warn_retrain",
    "_update_graph",
]

_show_bar = False
_multiprocessing = False
_jupiter_support = False
_ignore_missing = False
_warn_retrain = False
_update_graph = False
